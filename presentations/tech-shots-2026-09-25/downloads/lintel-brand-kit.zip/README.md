# Lintel — Folded L

Selected by Johannes Åkerman on 24 September 2026 as the primary Lintel logo.

The selected design is Folded L with subtle Fluent-inspired gradients, top-edge highlights and restrained shading. The asymmetric support and spanning beam retain the portal motif and form an architectural L. Keep the geometry, color and transparent opening intact.

- `lintel-logo.svg`: scalable master, including the approved shading. Use this for web, documentation and design work.
- `lintel-logo.png`: transparent 1254×1254PNG master.
- `favicon.ico`: 16/32/48-pixel browser icons in one file.
- `lintel-icon-16.png`, `32`, `48`, `180`, `192`, `512`: transparent exports for browser and app icon use.

The same full-color mark is used in the Neon and Paper presentation themes. Preserve the existing transparent margin; do not stretch, rotate or add effects. Use the flat vector only for reproduction processes that require flat inks; the earlier exploration remains archived separately.

Initial direction generated with built-in imagegen, then reconstructed as clean native SVG geometry and refined with shading. Original briefs and alternate directions remain in the logo-options archive. This brand kit is the selected delivery.
